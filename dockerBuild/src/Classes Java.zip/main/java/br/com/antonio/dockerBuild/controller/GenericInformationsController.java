package br.com.antonio.dockerBuild.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.antonio.dockerBuild.data.vo.GenericInformationsVO;
import br.com.antonio.dockerBuild.data.vo.GenericListVO;
import br.com.antonio.dockerBuild.services.GenericInformationsServices;

@RestController
@RequestMapping(value="/v1/api/generic")
public class GenericInformationsController {
	
	@Autowired
	private GenericInformationsServices services;
	
	@GetMapping(value="/getSingle", produces= {"application/json"})
	public GenericInformationsVO findSingle() {
		return services.findSingle();
	}
	
	@GetMapping(value="/getAll", produces= {"application/json"})
	public List<GenericInformationsVO> findAll() {
		List<GenericInformationsVO> generic = services.findAll();
		return generic;
	}
	
	@GetMapping(value="/getAll2", produces= {"application/json"})
	public List<?> findAll2() {
		List<?> generic = services.findAll2();
		//generic.stream().forEach(p -> p.add(methodOn(services.findAll())));
		return generic;
	}
	
	@GetMapping(value="/getAll3", produces= {"application/json"})
	public GenericListVO findAll3() {
		GenericListVO generic = services.findAll3();
		//generic.stream().forEach(p -> p.add(methodOn(services.findAll())));
		return generic;
	}

}

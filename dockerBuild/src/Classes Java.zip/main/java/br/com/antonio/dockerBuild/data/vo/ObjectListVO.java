package br.com.antonio.dockerBuild.data.vo;

import java.io.Serializable;
import java.util.List;

public class ObjectListVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private List<GenericInformationsVO> objectList;
	

	public ObjectListVO() {
		super();
		// TODO Auto-generated constructor stub
	}


	public List<GenericInformationsVO> getObjectList() {
		return objectList;
	}


	public void setObjectList(List<GenericInformationsVO> objectList) {
		this.objectList = objectList;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((objectList == null) ? 0 : objectList.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ObjectListVO other = (ObjectListVO) obj;
		if (objectList == null) {
			if (other.objectList != null)
				return false;
		} else if (!objectList.equals(other.objectList))
			return false;
		return true;
	}

	
	
	
	
	
}

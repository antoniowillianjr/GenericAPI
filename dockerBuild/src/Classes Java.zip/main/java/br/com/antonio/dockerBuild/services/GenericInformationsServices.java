package br.com.antonio.dockerBuild.services;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import org.springframework.stereotype.Service;

import br.com.antonio.dockerBuild.data.vo.GenericInformationsVO;
import br.com.antonio.dockerBuild.data.vo.GenericListVO;

@Service
public class GenericInformationsServices {

	private final AtomicLong counter = new AtomicLong();

	public GenericInformationsVO findSingle() {

		GenericInformationsVO gen = new GenericInformationsVO();
		gen.setId("KEY_PARAM");
		gen.setValue("VALUE_PARAM");
		
		return gen;
	}

	public List<GenericInformationsVO> findAll() {

		List<GenericInformationsVO> generic = new ArrayList<GenericInformationsVO>();

		for (int i = 0; i < 4; i++) {
			GenericInformationsVO gen = mockGeneric(i);
			generic.add(gen);
		}

		return generic;
	}

	private GenericInformationsVO mockGeneric(int i) {
		GenericInformationsVO gen = new GenericInformationsVO();
		long id = counter.incrementAndGet();
		String id2 = String.valueOf(id);

		gen.setId(id2);
		gen.setValue("VALUE_PARAM " + id2);
		return gen;
	}
	private GenericInformationsVO mockGeneric2(int a) {
		GenericInformationsVO gen = new GenericInformationsVO();
		long id = counter.incrementAndGet();
		String id2 = String.valueOf(id);
		
		gen.setId(id2);
		gen.setValue("VALUE_PARAM " + id2);
		return gen;
	}

	public List<GenericListVO> findAll2() {
		List<GenericListVO> generic = new ArrayList<GenericListVO>();
			
			for (int i = 0; i < 2; i++) {

			GenericListVO gg = genericParse(i);
			generic.add(gg);
		}
		
		return generic;

	}

//	private GenericListVO genericParse(int i) {
//		GenericListVO gen = new GenericListVO();
//		List<GenericInformationsVO> generic = new ArrayList<GenericInformationsVO>();
//
//		for (int a = 0; a < 4; a++) {
//			GenericInformationsVO gena = mockGeneric2(a);
//			generic.add(gena);
//		}
//		gen.setTransactionType("SMS");
//		gen.setGeneric(generic);
//		return gen;
//	}
	private GenericListVO genericParse(int i) {
		GenericListVO gen = new GenericListVO();
		List<GenericInformationsVO> generic = new ArrayList<GenericInformationsVO>();
		
		for (int a = 0; a < 4; a++) {
			GenericInformationsVO gena = mockGeneric2(a);
			generic.add(gena);
		}
		gen.setTransactionType("SMS");
		//gen.add(generic);
		return gen;
	}
	
	public GenericListVO findAll3() {
		List<GenericListVO> generic = new ArrayList<GenericListVO>();
		
		for (int i = 0; i < 2; i++) {

		GenericListVO gg = genericParseObject(i);
		generic.add(gg);
	}
		
		return generic;

	}
}

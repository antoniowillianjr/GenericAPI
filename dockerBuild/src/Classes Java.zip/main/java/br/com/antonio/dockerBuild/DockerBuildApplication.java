package br.com.antonio.dockerBuild;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DockerBuildApplication {

	public static void main(String[] args) {
		SpringApplication.run(DockerBuildApplication.class, args);
	}

}

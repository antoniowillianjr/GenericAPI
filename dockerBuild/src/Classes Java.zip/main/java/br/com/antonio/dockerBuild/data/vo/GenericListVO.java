package br.com.antonio.dockerBuild.data.vo;

import java.io.Serializable;
import java.util.List;

public class GenericListVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String transactionType;
	private List<ObjectListVO> generic;
	

	public GenericListVO() {
		super();
		// TODO Auto-generated constructor stub
	}


	public String getTransactionType() {
		return transactionType;
	}


	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}


	public List<ObjectListVO> getGeneric() {
		return generic;
	}


	public void setGeneric(List<ObjectListVO> generic) {
		this.generic = generic;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((generic == null) ? 0 : generic.hashCode());
		result = prime * result + ((transactionType == null) ? 0 : transactionType.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		GenericListVO other = (GenericListVO) obj;
		if (generic == null) {
			if (other.generic != null)
				return false;
		} else if (!generic.equals(other.generic))
			return false;
		if (transactionType == null) {
			if (other.transactionType != null)
				return false;
		} else if (!transactionType.equals(other.transactionType))
			return false;
		return true;
	}

	

	
	
	
	
}
